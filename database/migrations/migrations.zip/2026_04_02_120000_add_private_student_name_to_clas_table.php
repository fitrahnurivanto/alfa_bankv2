<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('clas', function (Blueprint $table) {
            $table->string('private_student_name')->nullable()->after('name');
        });
    }

    public function down(): void
    {
        Schema::table('clas', function (Blueprint $table) {
            $table->dropColumn('private_student_name');
        });
    }
};
