<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Registration extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'training_id',
        'registration_code',
        'full_name',
        'email',
        'phone',
        'whatsapp',
        'form_data',
        'payment_method',
        'status',
        'otp_verified_at',
        'payment_deadline',
        'expired_at',
        'ktp_file',
    ];

    protected $casts = [
        'form_data' => 'array',
        'otp_verified_at' => 'datetime',
        'payment_deadline' => 'datetime',
        'expired_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    // Relationships
    public function training()
    {
        return $this->belongsTo(Training::class);
    }

    public function otpVerification()
    {
        return $this->hasOne(OtpVerification::class);
    }

    public function invoice()
    {
        return $this->hasOne(Invoice::class);
    }

    public function payments()
    {
        return $this->hasOneThrough(Payment::class, Invoice::class);
    }

    // Scopes
    public function scopeActive($query)
    {
        return $query->where('status', '!=', 'cancelled')
            ->where('status', '!=', 'expired')
            ->where('expired_at', '>', now());
    }

    public function scopePending($query)
    {
        return $query->where('status', 'payment_pending');
    }

    public function scopePaid($query)
    {
        return $query->where('status', 'paid');
    }

    // Methods
    public function isExpired(): bool
    {
        return $this->expired_at && $this->expired_at < now();
    }

    public function isPaymentOverdue(): bool
    {
        return $this->payment_deadline && $this->payment_deadline < now() && $this->status !== 'paid';
    }

    public function generateUniqueCode(): string
    {
        do {
            $code = 'REG' . strtoupper(uniqid());
        } while (static::where('registration_code', $code)->exists());

        return $code;
    }

    public function getStatusLabel(): string
    {
        return match ($this->status) {
            'pending' => 'Menunggu',
            'terms_agreed' => 'Setuju Syarat',
            'data_verified' => 'Data Terverifikasi',
            'payment_pending' => 'Menunggu Pembayaran',
            'paid' => 'Sudah Dibayar',
            'cancelled' => 'Dibatalkan',
            'expired' => 'Kadaluarsa',
            default => 'Unknown',
        };
    }

    public function getStatusColor(): string
    {
        return match ($this->status) {
            'pending' => 'yellow',
            'terms_agreed' => 'blue',
            'data_verified' => 'cyan',
            'payment_pending' => 'orange',
            'paid' => 'green',
            'cancelled' => 'red',
            'expired' => 'gray',
            default => 'slate',
        };
    }
}
