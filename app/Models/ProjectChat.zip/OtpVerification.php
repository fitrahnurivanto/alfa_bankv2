<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OtpVerification extends Model
{
    protected $fillable = [
        'registration_id',
        'otp_code',
        'attempts',
        'verified_at',
        'expires_at',
    ];

    protected $casts = [
        'verified_at' => 'datetime',
        'expires_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    // Relationships
    public function registration()
    {
        return $this->belongsTo(Registration::class);
    }

    // Methods
    public function isExpired(): bool
    {
        return $this->expires_at < now();
    }

    public function isVerified(): bool
    {
        return $this->verified_at !== null;
    }

    public function canRetry(): bool
    {
        return $this->attempts < 3 && !$this->isExpired();
    }

    public function generateOTP(): string
    {
        return str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
    }

    public static function createForRegistration(Registration $registration): self
    {
        // Delete previous OTP
        static::where('registration_id', $registration->id)->delete();

        $otp = new static();
        $otp->registration_id = $registration->id;
        $otp->otp_code = $otp->generateOTP();
        $otp->expires_at = now()->addMinutes(10); // OTP valid 10 menit
        $otp->save();

        return $otp;
    }
}
